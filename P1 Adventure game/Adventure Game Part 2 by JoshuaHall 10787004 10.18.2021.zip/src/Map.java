
public class Map {
	public int rows;
	public int cols;

	public Map(int rows, int cols) {
		this.rows = rows;
		this.cols = cols;
	}
}
