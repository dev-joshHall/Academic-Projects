package hall;

public interface Shape {
    public void setLocation();
    public void getLocation();
    public void display();
    public void fill();
    public void setColor();
    public void undisplay();
}
