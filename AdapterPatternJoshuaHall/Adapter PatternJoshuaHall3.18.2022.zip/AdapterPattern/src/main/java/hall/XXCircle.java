package hall;

public class XXCircle {
    public void setLocation() {
        System.out.println("Setting circle location...");
    }

    public void getLocation() {
        System.out.println("Getting circle location...");
    }

    public void displayIt() {
        System.out.println("Displaying circle...");
    }

    public void fillIt() {
        System.out.println("Filling circle...");
    }

    public void setItsColor() {
        System.out.println("Setting circle color...");
    }

    public void undisplayIt() {
        System.out.println("Undisplaying circle...");
    }
}

